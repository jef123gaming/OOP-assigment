package Models;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DeliveryManager {
    private static final String DELIVERY_FILE = "data/deliveries.txt";
    private static List<Delivery> deliveries = new ArrayList<>();

    static {
        loadDeliveries();
    }

    private static void loadDeliveries() {
        deliveries.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(DELIVERY_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("::");
                if (parts.length == 6) {
                    int deliveryID = Integer.parseInt(parts[0]);
                    int orderId = Integer.parseInt(parts[1]);
                    String customerName = parts[2];
                    long deliveryDateMillis = Long.parseLong(parts[3]);
                    String status = parts[4];
                    String trackingNumber = parts[5];

                    Order order = this.orderManager.getOrderById(orderId);                    
                    Customer customer = Customer.getName(customerName); // <-- by Name, not ID
                    if (order != null && customer != null) {
                        Delivery delivery = new Delivery(deliveryID, order, customer, new Date(deliveryDateMillis));
                        delivery.updateStatus(status); // Set correct status
                        deliveries.add(delivery);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("❗ Error loading deliveries: " + e.getMessage());
        }
    }

    private static void saveDeliveries() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DELIVERY_FILE))) {
            for (Delivery delivery : deliveries) {
                writer.write(delivery.getDeliveryID() + "::" +
                             delivery.getOrder().getOrderId() + "::" +
                             delivery.getCustomer().getName() + "::" + // <-- getName()
                             delivery.getDeliveryDate().getTime() + "::" +
                             delivery.getStatus() + "::" +
                             delivery.getTrackingNumber());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("❗ Error saving deliveries: " + e.getMessage());
        }
    }

    public static void addDelivery(Delivery delivery) {
        deliveries.add(delivery);
        saveDeliveries();
    }

    public static int generateDeliveryId() {
        return deliveries.isEmpty() ? 1 : deliveries.get(deliveries.size() - 1).getDeliveryID() + 1;
    }

    public static Delivery getDeliveryById(int id) {
        return deliveries.stream()
                .filter(d -> d.getDeliveryID() == id)
                .findFirst()
                .orElse(null);
    }

    // -------- Admin Functions --------

    public static void viewAllDeliveries() {
        System.out.println("\n📦 All Deliveries:");
        for (Delivery delivery : deliveries) {
            System.out.println("--------------------------------------------");
            System.out.println("Delivery ID: " + delivery.getDeliveryID());
            System.out.println("Order ID: " + delivery.getOrder().getOrderId());
            System.out.println("Customer Name: " + delivery.getCustomer().getName()); // <-- getName()
            System.out.println("Tracking Number: " + delivery.getTrackingNumber());
            System.out.println("Delivery Date: " + new SimpleDateFormat("yyyy-MM-dd").format(delivery.getDeliveryDate()));
            System.out.println("Status: " + delivery.getStatus());
        }
    }

    public static void updateDeliveryStatus(Scanner scanner) {
        System.out.print("\nEnter Delivery ID to update: ");
        int deliveryId = Integer.parseInt(scanner.nextLine());
        Delivery delivery = getDeliveryById(deliveryId);

        if (delivery != null) {
            System.out.print("Enter new status (Pending / Shipped / Delivered): ");
            String newStatus = scanner.nextLine();
            delivery.updateStatus(newStatus);
            saveDeliveries();
            System.out.println("✅ Delivery status updated successfully.");
        } else {
            System.out.println("❗ Delivery ID not found.");
        }
    }

    public static void trackDelivery(Scanner scanner) {
        System.out.print("\nEnter your Delivery ID to track: ");
        int deliveryId = Integer.parseInt(scanner.nextLine());
        Delivery delivery = getDeliveryById(deliveryId);

        if (delivery != null) {
            System.out.println("\n📦 Tracking Information:");
            System.out.println("---------------------------------");
            System.out.println("Tracking Number: " + delivery.getTrackingNumber());
            System.out.println("Order ID: " + delivery.getOrder().getOrderId());
            System.out.println("Customer Name: " + delivery.getCustomer().getName()); // <-- getName()
            System.out.println("Status: " + delivery.getStatus());
            System.out.println("Estimated Delivery Date: " + new SimpleDateFormat("yyyy-MM-dd").format(delivery.getDeliveryDate()));
        } else {
            System.out.println("❗ Delivery ID not found. Please check again.");
        }
    }
}
