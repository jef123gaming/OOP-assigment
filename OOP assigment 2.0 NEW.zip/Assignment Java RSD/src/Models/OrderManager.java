package Models;

import java.io.*;
import java.util.*;

public class OrderManager {
    private List<Order> orders = new ArrayList<>();
    private String filePath;
    private ProductManager productManager;

    public OrderManager(String filePath, ProductManager productManager) {
        this.filePath = filePath;
        this.productManager = productManager;
        loadOrders();
    }

    private void loadOrders() {
        orders.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 5) {
                    int orderId = Integer.parseInt(parts[0]);
                    String customerName = parts[1];
                    Date orderDate = new Date(Long.parseLong(parts[2])); // timestamp stored
                    double totalAmount = Double.parseDouble(parts[3]);
                    String deliveryStatus = parts[4];

                    List<CartItem> items = new ArrayList<>();
                    if (parts.length > 5) {
                        for (int i = 5; i < parts.length; i++) {
                            String[] itemParts = parts[i].split(",");
                            if (itemParts.length == 2) {
                                int productId = Integer.parseInt(itemParts[0]);
                                int quantity = Integer.parseInt(itemParts[1]);

                                Product product = productManager.getProductById(productId);
                                if (product != null) {
                                    items.add(new CartItem(product, quantity));
                                }
                            }
                        }
                    }

                    Order order = new Order(orderId, customerName, orderDate, totalAmount, deliveryStatus, items);
                    orders.add(order);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading orders: " + e.getMessage());
        }
    }

    public void saveOrders() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Order order : orders) {
                StringBuilder sb = new StringBuilder();
                sb.append(order.getOrderId()).append(";");
                sb.append(order.getCustomerName()).append(";");
                sb.append(order.getOrderDate().getTime()).append(";");
                sb.append(order.getTotalAmount()).append(";");
                sb.append(order.getDeliveryStatus()).append(";");

                for (CartItem item : order.getItems()) {
                    sb.append(item.getProduct().getProductId()).append(",").append(item.getQuantity()).append(";");
                }

                writer.write(sb.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving orders: " + e.getMessage());
        }
    }

    public int generateOrderId() {
        if (orders.isEmpty()) {
            return 1;
        } else {
            return orders.get(orders.size() - 1).getOrderId() + 1;
        }
    }

    public List<Order> getAllOrders() {
        return orders;
    }

    public void addOrder(Order order) {
        orders.add(order);
        saveOrders();
    }

    public Order getOrderById(int id) {
        for (Order order : orders) {
            if (order.getOrderId() == id) {
                return order;
            }
        }
        return null;
    }
}
