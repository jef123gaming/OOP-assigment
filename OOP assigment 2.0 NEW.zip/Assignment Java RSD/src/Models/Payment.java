package Models;

import java.util.Date;

public class Payment {
    private int paymentID;
    private double amount;
    private Date paymentDate;
    private String paymentMethod; // e.g., "Credit Card", "Cash", "Online Banking"
    private String status; // e.g., "Paid", "Pending", "Refunded"

    // Constructor
    public Payment(int paymentID, double amount, Date paymentDate, String paymentMethod, String status) {
        this.paymentID = paymentID;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.status = status;
    }

    // Getters
    public int getPaymentID() {
        return paymentID;
    }

    public double getAmount() {
        return amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setStatus(String status) {
        this.status = status;
    }

    // Business methods
    public boolean processPayment() {
        if (!status.equalsIgnoreCase("Paid")) {
            status = "Paid";
            System.out.println("Payment processed successfully.");
            return true;
        } else {
            System.out.println("Payment already processed.");
            return false;
        }
    }

    public boolean refundPayment() {
        if (status.equalsIgnoreCase("Paid")) {
            status = "Refunded";
            System.out.println("Payment refunded successfully.");
            return true;
        } else {
            System.out.println("Cannot refund. Payment is not in 'Paid' status.");
            return false;
        }
    }

    @Override
    public String toString() {
        return "Payment ID: " + paymentID +
               ", Amount: RM" + amount +
               ", Payment Date: " + paymentDate +
               ", Method: " + paymentMethod +
               ", Status: " + status;
    }
}
