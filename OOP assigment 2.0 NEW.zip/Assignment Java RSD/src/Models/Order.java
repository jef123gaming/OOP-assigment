package Models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {
    private int orderId;
    private String customerName;
    private Date orderDate;
    private double totalAmount;
    private String deliveryStatus;
    private List<CartItem> items;

    public Order(int orderId, String customerName, Date orderDate, double totalAmount, String deliveryStatus, List<CartItem> items) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.deliveryStatus = deliveryStatus;
        this.items = items != null ? items : new ArrayList<>();
    }

    // Getters
    public int getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public List<CartItem> getItems() {
        return items;
    }

    // Setters
    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    // Business Logic
    public String generateInvoice() {
        StringBuilder invoice = new StringBuilder();
        invoice.append("Order ID: ").append(orderId).append("\n");
        invoice.append("Customer: ").append(customerName).append("\n");
        invoice.append("Order Date: ").append(orderDate).append("\n");
        invoice.append("Items:\n");

        for (CartItem item : items) {
            invoice.append("- ").append(item.getProduct().getName())
                   .append(" x ").append(item.getQuantity())
                   .append(" = RM").append(item.getProduct().getPrice() * item.getQuantity())
                   .append("\n");
        }

        invoice.append("Total: RM").append(totalAmount).append("\n");
        invoice.append("Delivery Status: ").append(deliveryStatus).append("\n");

        return invoice.toString();
    }

    public String trackOrder() {
        return "Order " + orderId + " is currently: " + deliveryStatus;
    }
}
