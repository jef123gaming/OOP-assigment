package Models;

import java.util.Date;
import java.util.Scanner;

public class CheckoutManager {
    private Cart cart;
    private OrderManager orderManager;
    private PaymentManager paymentManager;

    public CheckoutManager(Cart cart, OrderManager orderManager, PaymentManager paymentManager) {
        this.cart = cart;
        this.orderManager = orderManager;
        this.paymentManager = paymentManager;
    }

    public void checkout(Customer customer, String method) {
        Scanner scanner = new Scanner(System.in);
        
        cart.viewCart(); 

        double totalAmount = cart.getTotal(); // ✅ fixed
        System.out.println("Total Amount: RM" + totalAmount);

        System.out.println("\nProceed to Payment? (yes/no)");
        if (!scanner.nextLine().equalsIgnoreCase("yes")) {
            System.out.println("Checkout cancelled.");
            return;
        }

        // Generate payment
        int paymentId = PaymentManager.generatePaymentId();
        PaymentManager.makePayment(paymentId, totalAmount, method);
        
        // Generate order
        int orderId = orderManager.generateOrderId(); // ✅ will add this
        Date now = new Date();
        Order order = new Order(orderId, customer.getName(), now, totalAmount, "Processing", cart.getItems());
        orderManager.addOrder(order); // ✅ use addOrder

        // Clear cart after successful order
        cart.clearCart();
        System.out.print("Processing");
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(500); // 0.5 second delay
                System.out.print(".");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
        }
         
        Delivery delivery = new Delivery(
        DeliveryManager.generateDeliveryId(), order , customer, null );
        DeliveryManager.addDelivery(delivery); 

        cart.clearCart();
        System.out.println("\nPayment Successful!");
        System.out.println("📦 Delivery ID: " + delivery.getDeliveryID());
        System.out.println("🔍 Tracking Number: " + delivery.getTrackingNumber());
}
        System.out.println("\nPayment Successful!");
        System.out.println("Would you like an E-Receipt? (yes/no)");
        String eReceiptChoice = scanner.nextLine();
        if (eReceiptChoice.equalsIgnoreCase("yes")) {
            System.out.println("\n==== E-RECEIPT ====");
            System.out.println(order.generateInvoice());
        }

        System.out.println("\nYour order is being processed for delivery!");
        
    }
}
