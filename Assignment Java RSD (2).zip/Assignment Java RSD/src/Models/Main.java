import Models.*;

import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static UserManager userManager = new UserManager();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Welcome to the Computer Shop System ===");
            System.out.println("1. Register as Customer");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    registerCustomer();
                    break;
                case "2":
                    login();
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void registerCustomer() {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        boolean success = userManager.registerCustomer(name, email, password);
        if (success) {
            System.out.println("Registration successful.");
        } else {
            System.out.println("Email already exists. Try again.");
        }
    }

    private static void login() {
        System.out.print("Enter your name or email: ");
        String input = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        User user = userManager.login(input, password);
        if (user == null) {
            System.out.println("Login failed. Invalid credentials.");
            return;
        }

        if (user instanceof Admin) {
            System.out.println("Welcome Admin: " + user.getName());
            // Add Admin menu here in future
        } else if (user instanceof Customer) {
            System.out.println("Welcome Customer: " + user.getName());
            customerMenu((Customer) user);
        }
    }

    private static void customerMenu(Customer customer) {
        while (true) {
            System.out.println("\n--- Customer Menu ---");
            System.out.println("1. View Profile");
            System.out.println("2. Update Profile");
            System.out.println("3. Logout");
            System.out.print("Choose option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    viewCustomerProfile(customer);
                    break;
                case "2":
                    updateCustomerProfile(customer);
                    break;
                case "3":
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void viewCustomerProfile(Customer customer) {
        System.out.println("\n--- Your Profile ---");
        System.out.println("Name: " + customer.getName());
        System.out.println("Email: " + customer.getEmail());
        System.out.println("Address: " + customer.getAddress());
        System.out.println("Phone Number: " + customer.getPhoneNumber());
        System.out.println("Birth Date: " + customer.getBirthDate());
    }

    private static void updateCustomerProfile(Customer customer) {
        System.out.print("Enter new address: ");
        customer.setAddress(scanner.nextLine());
        System.out.print("Enter new phone number: ");
        customer.setPhoneNumber(scanner.nextLine());
        System.out.print("Enter birth date (YYYY-MM-DD): ");
        customer.setBirthDate(scanner.nextLine());

        userManager.updateCustomerFile();
        System.out.println("Profile updated successfully.");
    }
}
