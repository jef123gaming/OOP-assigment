package Models;

import java.util.Date;
import java.util.List;

public class Order {
    private int orderId;
    private Customer customer;
    private Date orderDate;
    private double totalAmount;
    private String deliveryStatus;
    private List<CartItem> items;

    // Constructor
    public Order(int orderId, Customer customer, Date orderDate, double totalAmount, String deliveryStatus, List<CartItem> items) {
        this.orderId = orderId;
        this.customer = customer;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.deliveryStatus = deliveryStatus;
        this.items = items;
    }

    // Getters & Setters
    public int getOrderId() {
        return orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    // Functional Methods
    public String generateInvoice() {
        // Simple invoice string, can be expanded later
        StringBuilder invoice = new StringBuilder();
        invoice.append("Invoice\n");
        invoice.append("Order ID: ").append(orderId).append("\n");
        invoice.append("Customer: ").append(customer.getName()).append("\n");
        invoice.append("Date: ").append(orderDate).append("\n");
        invoice.append("Items:\n");

        for (CartItem item : items) {
            invoice.append("- ").append(item.getProduct().getName())
                   .append(" x ").append(item.getQuantity())
                   .append(" = ").append(item.getSubtotal()).append("\n");
        }

        invoice.append("Total: ").append(totalAmount).append("\n");
        return invoice.toString();
    }

    public String trackOrder() {
        // This is a placeholder; real system might fetch tracking info from Delivery class
        return "Tracking status: " + deliveryStatus;
    }
}
