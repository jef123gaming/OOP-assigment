package Models;

import java.io.*;
import java.util.*;

public class ProductManager {
    private List<Product> products = new ArrayList<>();
    private String filePath;

    public ProductManager(String filePath) {
        this.filePath = filePath;
        loadProducts();
    }

    private void loadProducts() {
        products.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("::");
                if (parts.length == 6) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    double price = Double.parseDouble(parts[2]);
                    int stock = Integer.parseInt(parts[3]);
                    String category = parts[4];
                    String description = parts[5];
                    products.add(new Product(id, name, price, stock, category, description));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading products: " + e.getMessage());
        }
    }

    public void saveProducts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Product p : products) {
                writer.write(p.getProductId() + "::" + p.getName() + "::" + p.getPrice() + "::" +
                        p.getStock() + "::" + p.getCategory() + "::" + p.getDescription());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving products: " + e.getMessage());
        }
    }

    public void browseProducts(Scanner scanner, Cart cart) {
        while (true) {
            System.out.println("\n--- Product List ---");
            for (Product p : products) {
                System.out.println(p.getProductId() + ". " + p.getName() + " - RM" + p.getPrice() +
                        " (Stock: " + p.getStock() + ")");
            }
            System.out.println("0. Back to menu");
            System.out.print("Enter product ID to add to cart or 0 to return: ");
            String input = scanner.nextLine();
            if (input.equals("0")) return;

            try {
                int id = Integer.parseInt(input);
                Product selected = getProductById(id);
                if (selected != null && selected.getStock() > 0) {
                    System.out.print("Enter quantity: ");
                    int qty = Integer.parseInt(scanner.nextLine());
                    if (qty > 0 && qty <= selected.getStock()) {
                        cart.addItem(new CartItem(selected, qty));
                    } else {
                        System.out.println("Invalid quantity.");
                    }
                } else {
                    System.out.println("Invalid product or out of stock.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
            }
        }
    }

    public Product getProductById(int id) {
        for (Product p : products) {
            if (p.getProductId() == id) return p;
        }
        return null;
    }

    public List<Product> getAllProducts() {
        return products;
    }
} 