package Models;

import java.io.*;
import java.util.*;

public class PaymentManager {
    private static final String PAYMENT_FILE = "data/payments.txt";
    private static int lastPaymentId = 0;
    
    // Save a payment to file
    public static void savePayment(Payment payment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PAYMENT_FILE, true))) {
            writer.write(payment.getPaymentID() + "::" + payment.getAmount() + "::" +
                         payment.getPaymentDate().getTime() + "::" + payment.getPaymentMethod() + "::" +
                         payment.getStatus());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving payment: " + e.getMessage());
        }
    }
    
    // Load all payments
    public static List<Payment> loadPayments() {
        List<Payment> payments = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(PAYMENT_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("::");
                if (parts.length == 5) {
                    int id = Integer.parseInt(parts[0]);
                    double amount = Double.parseDouble(parts[1]);
                    Date paymentDate = new Date(Long.parseLong(parts[2]));
                    String method = parts[3];
                    String status = parts[4];
                    payments.add(new Payment(id, amount, paymentDate, method, status));

                    // Update lastPaymentId
                    if (id > lastPaymentId) {
                        lastPaymentId = id;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading payments: " + e.getMessage());
        }
        return payments;
    }

    // Generate the next payment ID
    public static int generatePaymentId() {
        return ++lastPaymentId;
    }

    // Choose and handle payment method
    public static String chooseAndHandlePaymentMethod(Scanner scanner, double totalAmount) {
        System.out.println("\n=== Choose Payment Method ===");
        System.out.println("1. Cash");
        System.out.println("2. Credit Card");
        System.out.println("3. E-Wallet");
        System.out.print("Enter your choice: ");
        
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                return handleCashPayment(scanner, totalAmount);
            case "2":
                System.out.println("✅ Payment via Credit Card selected.");
                return "Credit Card";
            case "3":
                System.out.println("✅ Payment via E-Wallet selected.");
                return "E-Wallet";
            default:
                System.out.println("⚠️ Invalid choice. Defaulting to Cash.");
                return handleCashPayment(scanner, totalAmount);
        }
    }

    // Handle Cash Payment
    public static String handleCashPayment(Scanner scanner, double totalAmount) {
        double amountGiven = 0;
        boolean valid = false;

        while (!valid) {
            System.out.print("Enter amount given by customer (RM): ");
            try {
                amountGiven = Double.parseDouble(scanner.nextLine());
                if (amountGiven < totalAmount) {
                    System.out.println("⚠️ Insufficient amount. Please provide at least RM" + totalAmount);
                } else {
                    valid = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input. Please enter a valid number.");
            }
        }

        double change = amountGiven - totalAmount;
        System.out.printf("✅ Payment accepted. Change to give: RM%.2f\n", change);
        return "Cash";
    }

    // Make and save payment
    public static Payment makePayment(int paymentId, double totalAmount, String method) {
        Payment payment = new Payment(paymentId, totalAmount, new Date(), method, "Completed");
        savePayment(payment);
        System.out.println("✅ Payment recorded successfully! (Payment ID: " + paymentId + ")");
        return payment;
    }
}
