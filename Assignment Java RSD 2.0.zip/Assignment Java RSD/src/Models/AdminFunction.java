package models;

import Models.Product;
import Models.ProductManager;

import java.util.List;
import java.util.Scanner;

public class AdminFunction {
    private ProductManager productManager;
    private Scanner scanner;

    public AdminFunction(ProductManager productManager) {
        this.productManager = productManager;
        this.scanner = new Scanner(System.in);
    }

    public void addProduct() {
        System.out.println("\n--- Add Product ---");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Price (RM): ");
        double price = Double.parseDouble(scanner.nextLine());
        System.out.print("Stock: ");
        int stock = Integer.parseInt(scanner.nextLine());
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();

        // Generate next productId
        int newId = productManager.getAllProducts().stream()
                .mapToInt(Product::getProductId)
                .max()
                .orElse(0) + 1;

        Product newProduct = new Product(newId, name, price, stock, category, description);
        productManager.getAllProducts().add(newProduct);
        productManager.saveProducts();

        System.out.println("✅ Product added successfully!");
    }

    public void deleteProduct() {
        System.out.println("\n--- Delete Product ---");
        System.out.print("Enter Product ID to delete: ");
        int id = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getProductById(id);
        if (product != null) {
            productManager.getAllProducts().remove(product);
            productManager.saveProducts();
            System.out.println("🗑️ Product deleted successfully.");
        } else {
            System.out.println("❌ Product not found.");
        }
    }

    public void updateProduct() {
        System.out.println("\n--- Update Product ---");
        System.out.print("Enter Product ID to update: ");
        int id = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getProductById(id);
        if (product != null) {
            System.out.println("Editing product: " + product.getName());
            System.out.println("1. Update Name");
            System.out.println("2. Update Price");
            System.out.println("3. Update Stock");
            System.out.println("4. Update Category");
            System.out.println("5. Update Description");
            System.out.println("0. Cancel");
            System.out.print("Choose option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    System.out.print("New name: ");
                    product.setName(scanner.nextLine());
                    break;
                case "2":
                    System.out.print("New price (RM): ");
                    product.setPrice(Double.parseDouble(scanner.nextLine()));
                    break;
                case "3":
                    System.out.print("New stock: ");
                    product.setStock(Integer.parseInt(scanner.nextLine()));
                    break;
                case "4":
                    System.out.print("New category: ");
                    product.setCategory(scanner.nextLine());
                    break;
                case "5":
                    System.out.print("New description: ");
                    product.setDescription(scanner.nextLine());
                    break;
                case "0":
                    System.out.println("Update cancelled.");
                    return;
                default:
                    System.out.println("Invalid option.");
                    return;
            }

            productManager.saveProducts();
            System.out.println("✅ Product updated successfully.");
        } else {
            System.out.println("❌ Product not found.");
        }
    }
    
    
    // TODO: Implement this once OrderManager is ready
    public void viewAllOrders() {
        System.out.println("🔧 [TODO] View All Orders feature is not implemented yet.");
    }

    // TODO: Implement this once OrderManager is ready
    public void updateOrderStatus() {
        System.out.println("🔧 [TODO] Update Order Status feature is not implemented yet.");
    }
}
