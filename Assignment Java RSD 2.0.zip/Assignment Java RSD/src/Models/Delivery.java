package Models;
import java.util.Date;

public class Delivery {
    private int DeliveryID;
    private Order order;
    private Customer customer;
    private Date DeliveryDate;
    private String Status;
    private String TrackingNumber;
    
    public Delivery(int DeliveryID ,Order order,Customer customer,Date DeliveryDate){
        this.DeliveryID = DeliveryID;
        this.order = order;
        this.customer = customer;
        this.DeliveryDate = DeliveryDate;
        this.Status = "Pending";// this is default status
        this.TrackingNumber = generateTrackingNumber();
    }
    
    public void updateStatus(String newStatus) {
        this.Status = newStatus;
        
        if (newStatus.equals("Shipped")) {
            this.DeliveryDate = new Date(); // Auto-set current date
            System.out.println("📅 Shipping date set to: " + DeliveryDate);
        }
        
        System.out.println("✅ Status updated to: " + newStatus);
    }

    private String generateTrackingNumber() {
        return "TN-" + DeliveryID + "-" + 
               customer.getCustomerId().substring(0, 4).toUpperCase();
    }

    // Getters
    public int getDeliveryID() { return DeliveryID; }
    public String getTrackingNumber() { return TrackingNumber; }
    public String getStatus() { return Status; }
    public Date getDeliveryDate() { return DeliveryDate; }
  }
