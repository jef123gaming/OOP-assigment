<?php
require 'functions.php';
logoutUser();
?>
