package Models;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
    private String address;
    private String phoneNumber;
    private List<Order> orderHistory;
    private String birthDate; // using String for simplicity

    public Customer(String name, String email, String password) {
        super(name, email, password);
        this.address = "";
        this.phoneNumber = "";
        this.birthDate = "";
        this.orderHistory = new ArrayList<>();
    }

    // Getters and setters
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public List<Order> getOrderHistory() {
        return orderHistory;
    }

    public void addToOrderHistory(Order order) {
        this.orderHistory.add(order);
    }

    public void viewOrderHistory() {
        if (orderHistory.isEmpty()) {
            System.out.println("No orders yet.");
        } else {
            for (Order order : orderHistory) {
                System.out.println(order);
            }
        }
    }

    public void addToCart(CartItem item) {
        System.out.println("Item added to cart: " + item.getProduct().getName());
        // You might want to actually implement a cart structure
    }

    public void checkout() {
        System.out.println("Checking out...");
        // logic goes here
    }

    public void redeemPoints() {
        System.out.println("Redeeming points...");
    }
}
