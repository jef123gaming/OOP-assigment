package Models;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UserManager userManager = new UserManager();

        while (true) {
            System.out.println("\n===== Computer Shop System =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            if (choice == 1) {
                // Customer Registration
                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Email: ");
                String email = sc.nextLine();
                System.out.print("Enter Password: ");
                String pass = sc.nextLine();

                if (userManager.register(name, email, pass)) {
                    System.out.println("✅ Registration successful!");
                } else {
                    System.out.println("❌ Email already exists.");
                }

            } else if (choice == 2) {
                // Login
                System.out.print("Enter Email or Name: ");
                String emailOrName = sc.nextLine();
                System.out.print("Enter Password: ");
                String pass = sc.nextLine();

                User user = userManager.login(emailOrName, pass);
                if (user != null) {
                    System.out.println("✅ Welcome, " + user.getName() + "!");
                    if (user instanceof Admin) {
                        showAdminMenu(sc, (Admin) user);
                    } else if (user instanceof Customer) {
                        showCustomerMenu(sc, (Customer) user);
                    }
                } else {
                    System.out.println("❌ Invalid login credentials.");
                }

            } else if (choice == 3) {
                System.out.println("👋 Bye!");
                break;
            } else {
                System.out.println("❗ Invalid option!");
            }
        }

        sc.close();
    }

    // Admin Menu
    private static void showAdminMenu(Scanner sc, Admin admin) {
        while (true) {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("1. View All Users");
            System.out.println("2. Manage Products");
            System.out.println("3. Logout");
            System.out.print("Choose: ");
            int adminChoice = sc.nextInt();
            sc.nextLine(); // consume newline

            if (adminChoice == 1) {
                System.out.println("[TODO] Show all registered users.");
                // Display users (not implemented yet)
            } else if (adminChoice == 2) {
                System.out.println("[TODO] Admin product management.");
                // Product management (not implemented yet)
            } else if (adminChoice == 3) {
                System.out.println("✅ Logged out.");
                break;
            } else {
                System.out.println("❗ Invalid choice.");
            }
        }
    }

    // Customer Menu
    private static void showCustomerMenu(Scanner sc, Customer customer) {
        while (true) {
            System.out.println("\n=== Customer Menu ===");
            System.out.println("1. Browse Products");
            System.out.println("2. View Cart");
            System.out.println("3. Logout");
            System.out.print("Choose: ");
            int custChoice = sc.nextInt();
            sc.nextLine(); // consume newline

            if (custChoice == 1) {
                System.out.println("[TODO] Browse product catalog.");
                // Browse products (not implemented yet)
            } else if (custChoice == 2) {
                System.out.println("[TODO] Show shopping cart.");
                // Shopping cart (not implemented yet)
            } else if (custChoice == 3) {
                System.out.println("✅ Logged out.");
                break;
            } else {
                System.out.println("❗ Invalid choice.");
            }
        }
    }
}
