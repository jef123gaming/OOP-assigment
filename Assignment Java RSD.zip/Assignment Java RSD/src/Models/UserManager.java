package Models;

import java.io.*;
import java.util.*;

public class UserManager {
    private static final String CUSTOMER_FILE = "users.txt";
    private static final String ADMIN_FILE = "admins.txt";
    private List<User> customers;
    private List<User> admins;

    public UserManager() {
        customers = new ArrayList<>();
        admins = new ArrayList<>();
        loadUsers();
        loadAdmins();  // Loading admins from file
    }

    // Load customers from the file
    private void loadUsers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                User user = User.fromFileString(line);
                if (user != null) {
                    customers.add(user);
                }
            }
        } catch (IOException e) {
            System.out.println("No customer data found.");
        }
    }

    // Load admins from the file (no registration via the code)
    private void loadAdmins() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ADMIN_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Admin admin = Admin.fromFileString(line);
                if (admin != null) {
                    admins.add(admin);
                }
            }
        } catch (IOException e) {
            System.out.println("No admin data found.");
        }
    }

    // Register a new customer
    public boolean register(String name, String email, String password) {
        if (getUserByEmail(email) != null) {
            return false;
        }
        User customer = new Customer(name, email, password);
        customers.add(customer);
        saveCustomer(customer);
        return true;
    }

    // Save customer to the file
    private void saveCustomer(User user) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CUSTOMER_FILE, true))) {
            writer.write(user.toFileString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving user: " + e.getMessage());
        }
    }

    // Login method for both admins and customers
    public User login(String input, String password) {
        // Check admins first
        for (User admin : admins) {
            if ((admin.getEmail().equalsIgnoreCase(input) || admin.getName().equalsIgnoreCase(input))
                    && admin.getPassword().equals(password)) {
                return admin; // Admin login
            }
        }

        // Then check customers
        for (User customer : customers) {
            if ((customer.getEmail().equalsIgnoreCase(input) || customer.getName().equalsIgnoreCase(input))
                    && customer.getPassword().equals(password)) {
                return customer;
            }
        }

        return null; // Not found
    }

    // Get user by email (admin or customer)
    public User getUserByEmail(String email) {
        for (User user : customers) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        for (User user : admins) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        return null;
    }
}
