package Models;

import java.util.List;
import java.util.Scanner;

public class AdminFunction {
    private ProductManager productManager;
    private Scanner scanner;

    public AdminFunction(ProductManager productManager) {
        this.productManager = productManager;
        this.scanner = new Scanner(System.in);
    }

    public void addProduct() {
        System.out.println("\n--- Add Product ---");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Price (RM): ");
        double price = Double.parseDouble(scanner.nextLine());
        System.out.print("Stock: ");
        int stock = Integer.parseInt(scanner.nextLine());
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();

        // Generate next productId
        int newId = productManager.getAllProducts().stream()
                .mapToInt(Product::getProductId)
                .max()
                .orElse(0) + 1;

        Product newProduct = new Product(newId, name, price, stock, category, description);
        productManager.getAllProducts().add(newProduct);
        productManager.saveProducts();

        System.out.println("✅ Product added successfully!");
    }

    public void deleteProduct() {
        System.out.println("\n--- Delete Product ---");
        System.out.print("Enter Product ID to delete: ");
        int id = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getProductById(id);
        if (product != null) {
            productManager.getAllProducts().remove(product);
            productManager.saveProducts();
            System.out.println("🗑️ Product deleted successfully.");
        } else {
            System.out.println("❌ Product not found.");
        }
    }

    public void updateProduct() {
        System.out.println("\n--- Update Product ---");
        System.out.print("Enter Product ID to update: ");
        int id = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getProductById(id);
        if (product != null) {
            System.out.println("Editing product: " + product.getName());
            System.out.println("1. Update Name");
            System.out.println("2. Update Price");
            System.out.println("3. Update Stock");
            System.out.println("4. Update Category");
            System.out.println("5. Update Description");
            System.out.println("0. Cancel");
            System.out.print("Choose option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    System.out.print("New name: ");
                    product.setName(scanner.nextLine());
                    break;
                case "2":
                    System.out.print("New price (RM): ");
                    product.setPrice(Double.parseDouble(scanner.nextLine()));
                    break;
                case "3":
                    System.out.print("New stock: ");
                    product.setStock(Integer.parseInt(scanner.nextLine()));
                    break;
                case "4":
                    System.out.print("New category: ");
                    product.setCategory(scanner.nextLine());
                    break;
                case "5":
                    System.out.print("New description: ");
                    product.setDescription(scanner.nextLine());
                    break;
                case "0":
                    System.out.println("Update cancelled.");
                    return;
                default:
                    System.out.println("Invalid option.");
                    return;
            }

            productManager.saveProducts();
            System.out.println("✅ Product updated successfully.");
        } else {
            System.out.println("❌ Product not found.");
        }
    }
    
    public void manageDeliveries() {
        while (true) {
            System.out.println("\n=== DELIVERY MANAGEMENT ===");
            System.out.println("1. View Delivery");
            System.out.println("2. Update Delivery Status");
            System.out.println("3. Back to Main Menu");
            System.out.print("Choose option: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    viewDelivery();
                    break;
                case "2":
                    updateDeliveryStatus();
                    break;
                case "3":
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private void viewDelivery() {
        System.out.print("Enter Delivery ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        Delivery delivery = DeliveryManager.getDeliveryById(id);
        if (delivery != null) {
            System.out.println("\n=== DELIVERY DETAILS ===");
            System.out.println("Delivery ID: " + delivery.getDeliveryID());
            System.out.println("Order ID: " + delivery.getOrder().getOrderId());
            System.out.println("Customer: " + delivery.getCustomer().getName());
            System.out.println("Status: " + delivery.getStatus());
            System.out.println("Tracking #: " + delivery.getTrackingNumber());
            if (delivery.getDeliveryDate() != null) {
                System.out.println("Shipping Date: " + delivery.getDeliveryDate());
            }
        } else {
            System.out.println("Delivery not found!");
        }
    }

    private void updateDeliveryStatus() {
        System.out.print("Enter Delivery ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        
        Delivery delivery = DeliveryManager.getDeliveryById(id);
        if (delivery != null) {
            System.out.println("\nCurrent Status: " + delivery.getStatus());
            System.out.println("1. Processing");
            System.out.println("2. Shipped");
            System.out.println("3. Out for Delivery");
            System.out.println("4. Delivered");
            System.out.print("Select new status: ");
            
            String[] statuses = {"Processing", "Shipped", "Out for Delivery", "Delivered"};
            int choice = Integer.parseInt(scanner.nextLine());
            
            if (choice >= 1 && choice <= 4) {
                delivery.updateStatus(statuses[choice-1]);
                DeliveryManager.saveDeliveries();
                System.out.println("Status updated!");
            } else {
                System.out.println("Invalid choice!");
            }
        } else {
            System.out.println("Delivery not found!");
        }
    }
    
        public void viewAllOrders() {
        System.out.println("\n=== View All Orders ===");

        List<Order> orders = OrderManager.loadOrders(); 

        if (orders.isEmpty()) {
            System.out.println("No orders found.");
            return;
        }

        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Customer Name: " + order.getCustomerName());
            System.out.println("Order Date: " + order.getOrderDate());
            System.out.println("Status: " + order.getDeliveryStatus());
            System.out.println("---------------------------");
        }
    }

    // Update order status
    public void updateOrderStatus() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n=== Update Order Status ===");
        System.out.print("Enter Order ID to update: ");
        int orderId = Integer.parseInt(scanner.nextLine());

        Order order = OrderManager.getOrderById(orderId); 

        if (order != null) {
            System.out.print("Enter new status (e.g., Processing, Shipped, Delivered): ");
            String newStatus = scanner.nextLine();
            order.setDeliveryStatus(newStatus);

            OrderManager.saveOrders();
            System.out.println("✅ Order status updated successfully!");
        } else {
            System.out.println("❌ Order not found.");
        }
    }
    
}