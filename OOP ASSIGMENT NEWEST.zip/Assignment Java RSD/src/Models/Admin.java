package Models;

public class Admin extends User {
    private String position;

    public Admin(String name, String email, String password, String position) {
        super(name, email, password);
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toFileString() {
        return "admin," + getName() + "," + getEmail() + "," + getPassword() + "," + position;
    }

    public static Admin fromFileString(String data) {
        String[] parts = data.split(",", -1);
        if (parts.length == 5 && parts[0].equalsIgnoreCase("admin")) {
            return new Admin(parts[1], parts[2], parts[3], parts[4]);
        }
        return null;
    }
}
