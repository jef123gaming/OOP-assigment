package Models;

public class Product {
    private int productId;
    private String name;
    private double price;
    private int stock;
    private String category;
    private String description;

    public Product(int productId, String name, double price, int stock, String category, String description) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.category = category;
        this.description = description;
    }

    // Getters
    public int getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Business Logic
    public void updateStock(int quantity) {
        this.stock -= quantity;
    }

    public boolean isLowStock() {
        return this.stock < 5;
    }

    public String getDetails() {
        return name + " - RM" + price + " | Stock: " + stock + " | Category: " + category + "\nDescription: " + description;
    }
}
