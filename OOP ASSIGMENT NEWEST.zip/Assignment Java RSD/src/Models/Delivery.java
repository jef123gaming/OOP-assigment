package Models;

import java.util.Date;

public class Delivery {
    private int deliveryID;
    Order order;           // Package-private so DeliveryManager can access it
    Customer customer;     // Package-private
    private Date deliveryDate;
    private String status;
    private String trackingNumber;
    
    public Delivery(int deliveryID, Order order, Customer customer, Date deliveryDate) {
        this.deliveryID = deliveryID;
        this.order = order;
        this.customer = customer;
        this.deliveryDate = deliveryDate;
        this.status = "Pending"; // Default status
        this.trackingNumber = generateTrackingNumber();
    }
    
    private String generateTrackingNumber() {
        return "TN-" + deliveryID + "-" + customer.getName().substring(0, 4).toUpperCase();
    }
    
    public void updateStatus(String newStatus) {
        this.status = newStatus;
        
        if (newStatus.equalsIgnoreCase("Shipped")) {
            this.deliveryDate = new Date(); // Auto-set current date
            System.out.println("📅 Shipping date set to: " + deliveryDate);
        }
        
        System.out.println("✅ Status updated to: " + newStatus);
    }
    
    // --- Getters ---
    public int getDeliveryID() { return deliveryID; }
    public String getTrackingNumber() { return trackingNumber; }
    public String getStatus() { return status; }
    public Date getDeliveryDate() { return deliveryDate; }
    public Order getOrder() { return order; }
    public Customer getCustomer() { return customer; }

    public void setTrackingNumber(String trackingNumber){
        this.trackingNumber = trackingNumber;
    }
}
