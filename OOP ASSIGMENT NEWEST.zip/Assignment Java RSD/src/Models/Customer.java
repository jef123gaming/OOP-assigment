package Models;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {
    private String address;
    private String phoneNumber;
    private String birthDate;
    private List<Order> orderHistory;

    public Customer(String name, String email, String password) {
        super(name, email, password);
        this.address = "";
        this.phoneNumber = "";
        this.birthDate = "";
        this.orderHistory = new ArrayList<>();
    }

    // Setters and getters
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public List<Order> getOrderHistory() {
        return orderHistory;
    }

    public void addOrder(Order order) {
        this.orderHistory.add(order);
    }

    public String toFileString() {
        return "customer," + getName() + "," + getEmail() + "," + getPassword() + "," +
               address + "," + phoneNumber + "," + birthDate;
    }

    public static Customer fromFileString(String data) {
        String[] parts = data.split(",", -1); // keep empty fields
        if (parts.length >= 4 && parts[0].equalsIgnoreCase("customer")) {
            Customer c = new Customer(parts[1], parts[2], parts[3]);
            if (parts.length > 4) c.setAddress(parts[4]);
            if (parts.length > 5) c.setPhoneNumber(parts[5]);
            if (parts.length > 6) c.setBirthDate(parts[6]);
            return c;
        }
        return null;
    }
}
