package Models;

import java.io.*;
import java.util.*;

public class UserManager {
    private static final String CUSTOMER_FILE = "users.txt";
    private static final String ADMIN_FILE = "admins.txt";
    private List<Customer> customers;
    private List<Admin> admins;

    public UserManager() {
        customers = new ArrayList<>();
        admins = new ArrayList<>();
        loadCustomers();
        loadAdmins();
    }

    private void loadCustomers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Customer customer = Customer.fromFileString(line);
                if (customer != null) {
                    customers.add(customer);
                }
            }
        } catch (IOException e) {
            System.out.println("No customer data found.");
        }
    }

    private void loadAdmins() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ADMIN_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Admin admin = Admin.fromFileString(line);
                if (admin != null) {
                    admins.add(admin);
                }
            }
        } catch (IOException e) {
            System.out.println("No admin data found.");
        }
    }

    public boolean registerCustomer(String name, String email, String password) {
        if (getUserByEmail(email) != null) {
            return false; // Email already used
        }
        Customer newCustomer = new Customer(name, email, password);
        customers.add(newCustomer);
        saveCustomer(newCustomer);
        return true;
    }

    private void saveCustomer(Customer customer) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CUSTOMER_FILE, true))) {
            writer.write(customer.toFileString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving customer: " + e.getMessage());
        }
    }

    public User login(String input, String password) {
        for (Admin admin : admins) {
            if ((admin.getEmail().equalsIgnoreCase(input) || admin.getName().equalsIgnoreCase(input))
                    && admin.getPassword().equals(password)) {
                return admin;
            }
        }
        for (Customer customer : customers) {
            if ((customer.getEmail().equalsIgnoreCase(input) || customer.getName().equalsIgnoreCase(input))
                    && customer.getPassword().equals(password)) {
                return customer;
            }
        }
        return null;
    }

    public User getUserByEmail(String email) {
        for (Customer c : customers) {
            if (c.getEmail().equalsIgnoreCase(email)) return c;
        }
        for (Admin a : admins) {
            if (a.getEmail().equalsIgnoreCase(email)) return a;
        }
        return null;
    }

    public void updateCustomerFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CUSTOMER_FILE))) {
            for (Customer customer : customers) {
                writer.write(customer.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error updating customer file.");
        }
    }
}
