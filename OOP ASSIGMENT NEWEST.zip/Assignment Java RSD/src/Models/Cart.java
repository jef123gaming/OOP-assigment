package Models;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class Cart {
    private int cartId;
    private List<CartItem> items;

    public Cart(int cartId) {
        this.cartId = cartId;
        this.items = new ArrayList<>();
    }
    public void addItem(CartItem item) {
        // Validate input
        if (item == null || item.getProduct() == null) {
            throw new IllegalArgumentException("Invalid cart item");
        }

        // Check if product already exists in cart
        for (CartItem existingItem : items) {
            if (existingItem.getProduct().getProductId() == item.getProduct().getProductId()) {
                int newQuantity = existingItem.getQuantity() + item.getQuantity();
                validateStock(item.getProduct(), newQuantity);
                existingItem.setQuantity(newQuantity);
                return;
            }
        }

        // Validate stock for new item
        validateStock(item.getProduct(), item.getQuantity());
        items.add(item);
    }

    public void removeItem(int productId) {
        items.removeIf(item -> 
            item.getProduct().getProductId() == productId
        );
    }

    public void updateQuantity(int productId, int newQuantity) {
        for (CartItem item : items) {
            if (item.getProduct().getProductId() == productId) {
                validateStock(item.getProduct(), newQuantity);
                item.setQuantity(newQuantity);
                return;
            }
        }
        throw new NoSuchElementException("Product not found in cart");
    }
    public void viewCart() {
        if (items.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        System.out.println("===== YOUR CART =====");
        for (CartItem item : items) {
            System.out.printf("%s x %d = RM%.2f%n",
                item.getProduct().getName(),
                item.getQuantity(),
                item.getTotalPrice()
            );
        }
        System.out.println("======================");
        System.out.printf("Total: RM%.2f%n", getTotal());
    }

    public void clearCart() {
        items.clear();
    }

    public double getTotal() {
        return items.stream()
                   .mapToDouble(CartItem::getTotalPrice)
                   .sum();
    }

    private void validateStock(Product product, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        if (quantity > product.getStock()) {
            throw new IllegalArgumentException(
                String.format("Only %d units available for %s", 
                    product.getStock(), 
                    product.getName())
            );
        }
    }

    // Getters
    public int getCartId() {
        return cartId;
    }

    public List<CartItem> getItems() {
        return new ArrayList<>(items); // Return copy to prevent external modification
    }
}