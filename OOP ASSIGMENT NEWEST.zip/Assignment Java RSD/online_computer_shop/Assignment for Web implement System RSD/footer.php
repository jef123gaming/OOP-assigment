<?php
// footer.php
echo '
    <footer>
        <p>&copy; 2024 designed by AAAAAAAAA</p>
    </footer>
</body>
</html>';
?>